import { initializeApp } from "firebase/app";

import {
  getMessaging,
  isSupported,
  onMessage,
  onRegistered,
  register,
  type MessagePayload,
  type Messaging,
} from "firebase/messaging";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,

  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,

  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,

  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,

  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,

  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);

async function getMessagingInstance(): Promise<Messaging> {
  const supported = await isSupported();

  if (!supported) {
    throw new Error(
      "Firebase Cloud Messaging is not supported by this browser",
    );
  }

  return getMessaging(app);
}

/**
 * Requests browser notification permission and registers this
 * browser instance with Firebase Cloud Messaging.
 *
 * @returns Firebase Installation ID (FID).
 */
export async function registerForPushNotifications(): Promise<string> {
  if (!("Notification" in window)) {
    throw new Error("Notifications are not supported by this browser");
  }

  const permission = await Notification.requestPermission();

  if (permission !== "granted") {
    throw new Error("Notification permission was not granted");
  }

  const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY;

  if (!vapidKey) {
    throw new Error("VITE_FIREBASE_VAPID_KEY is not configured");
  }

  const messaging = await getMessagingInstance();

  return new Promise<string>((resolve, reject) => {
    const timeout = window.setTimeout(() => {
      reject(new Error("Timed out waiting for Firebase Installation ID"));
    }, 15_000);

    const unsubscribe = onRegistered(messaging, (installationId) => {
      window.clearTimeout(timeout);

      unsubscribe();

      resolve(installationId);
    });

    void register(messaging, {
      vapidKey,
    }).catch((error: unknown) => {
      window.clearTimeout(timeout);

      unsubscribe();

      reject(error);
    });
  });
}

/**
 * Subscribes to FCM messages received while the application
 * is open in the foreground.
 */
export async function listenForForegroundMessages(
  listener: (payload: MessagePayload) => void,
): Promise<() => void> {
  const messaging = await getMessagingInstance();

  return onMessage(messaging, listener);
}
